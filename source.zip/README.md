# Fire Redstone Builder (Fabric 1.21.11)

A small starter mod project for Minecraft Java 1.21.11 + Fabric.

## Included
- `/redbuild help` — show commands.
- `/redbuild door` — builds a starter iron door with pressure plates on both sides.
- `/redbuild robot` — spawns a cosmetic FireBot armor stand that slowly follows nearby players and emits decorative flame particles.
- `/redbuild stopbots` — removes FireBots within 48 blocks.

Important: this first version does not include a true 2x2 flush piston door, animated legs, or fireball projectiles. The robot's flames are visual effects only. This keeps the starter mod focused on safe, beginner-friendly redstone builds.

## Requirements
- Minecraft Java 1.21.11
- Fabric Loader 0.18.1 or newer
- Java Development Kit (JDK) 21
- Fabric API 0.141.4+1.21.11

## Build the JAR
1. Extract this folder on a computer with JDK 21 and internet access.
2. Open a terminal in this folder.
3. If you have Gradle installed, run:
   - Windows: `gradle build`
   - Linux/macOS: `gradle build`
4. The mod JAR should appear in `build/libs/`.

This source bundle does not include a compiled JAR or Gradle wrapper. Gradle downloads Minecraft/Fabric build dependencies during the first build. If the build fails, update Loom/Fabric versions using https://fabricmc.net/develop/.

## Install
Copy the built `fire-redstone-builder-1.0.0.jar` from `build/libs/` into the Minecraft instance's `mods` folder. Install Fabric API for 1.21.11 in the same instance.

## Notes
The project uses Mojang mappings and Java 21. It is a starter project and should be compiled and tested before using in a main world. Try it in a creative test world first.
