package com.pixelcore.fireredstone;

import com.mojang.blaze3d.platform.InputConstants;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.KeyMapping;
import net.minecraft.resources.Identifier;

public class FireRedstoneBuilderClient implements ClientModInitializer {
    private static KeyMapping openMenuKey;

    @Override
    public void onInitializeClient() {
        KeyMapping.Category category = KeyMapping.Category.register(
                Identifier.fromNamespaceAndPath("fireredstone", "main"));

        // Custom keybind: K by default. Players can change it in Options > Controls.
        openMenuKey = KeyBindingHelper.registerKeyBinding(new KeyMapping(
                "key.fireredstone.open_menu",
                InputConstants.Type.KEYSYM,
                InputConstants.KEY_K,
                category));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (openMenuKey.consumeClick()) {
                if (client.getConnection() != null) {
                    client.getConnection().sendCommand("redbuild menu");
                }
            }
        });
    }
}
