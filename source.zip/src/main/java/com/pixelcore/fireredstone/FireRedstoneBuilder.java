package com.pixelcore.fireredstone;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.StringArgumentType;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.commands.CommandBuildContext;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.commands.SharedSuggestionProvider;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.decoration.ArmorStand;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.DoorBlock;
import net.minecraft.world.level.block.state.properties.DoubleBlockHalf;
import net.minecraft.world.phys.AABB;

public class FireRedstoneBuilder implements ModInitializer {
    private static final String ROBOT_TAG = "fireredstone_firebot";

    @Override
    public void onInitialize() {
        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) ->
                registerCommands(dispatcher));
        ServerTickEvents.END_SERVER_TICK.register(FireRedstoneBuilder::tickRobots);
    }

    private static void registerCommands(CommandDispatcher<CommandSourceStack> dispatcher) {
        dispatcher.register(Commands.literal("redbuild")
                .then(Commands.literal("help").executes(ctx -> {
                    var source = ctx.getSource();
                    source.sendSuccess(() -> Component.literal(
                            "Fire Redstone Builder: /redbuild door | /redbuild robot | /redbuild stopbots"), false);
                    source.sendSuccess(() -> Component.literal(
                            "door = simple pressure-plate iron door; robot = cosmetic moving FireBot; stopbots = remove nearby FireBots."), false);
                    return 1;
                }))
                .then(Commands.literal("door").executes(ctx -> buildDoor(ctx.getSource())))
                .then(Commands.literal("robot").executes(ctx -> spawnRobot(ctx.getSource())))
                .then(Commands.literal("stopbots").executes(ctx -> removeRobots(ctx.getSource()))));
    }

    private static int buildDoor(CommandSourceStack source) throws com.mojang.brigadier.exceptions.CommandSyntaxException {
        ServerPlayer player = source.getPlayerOrException();
        ServerLevel level = source.getLevel();
        BlockPos feet = player.blockPosition();
        Direction facing = player.getDirection();
        // Door is placed 3 blocks in front of the player. It is a real, working iron door
        // with pressure plates on both sides; it is a starter build, not a piston flush door.
        BlockPos base = feet.relative(facing, 3);
        Direction right = facing.getClockWise();

        // Clear a small area and make a 3-wide floor and wall.
        for (int side = -1; side <= 1; side++) {
            for (int depth = -1; depth <= 1; depth++) {
                BlockPos floor = base.relative(right, side).relative(facing.getOpposite(), depth).below();
                level.setBlockAndUpdate(floor, Blocks.STONE.defaultBlockState());
            }
        }
        // Wall frame, two blocks tall. Door opening is at side=0.
        for (int side = -1; side <= 1; side++) {
            for (int height = 0; height <= 2; height++) {
                if (side == 0 && height <= 1) continue;
                BlockPos wall = base.relative(right, side).above(height);
                level.setBlockAndUpdate(wall, Blocks.STONE_BRICKS.defaultBlockState());
            }
        }

        BlockPos lower = base;
        BlockPos upper = base.above();
        level.setBlockAndUpdate(lower, Blocks.IRON_DOOR.defaultBlockState()
                .setValue(DoorBlock.FACING, facing)
                .setValue(DoorBlock.HALF, DoubleBlockHalf.LOWER));
        level.setBlockAndUpdate(upper, Blocks.IRON_DOOR.defaultBlockState()
                .setValue(DoorBlock.FACING, facing)
                .setValue(DoorBlock.HALF, DoubleBlockHalf.UPPER));

        // Pressure plates outside and inside the entrance.
        level.setBlockAndUpdate(base.relative(facing), Blocks.STONE_PRESSURE_PLATE.defaultBlockState());
        level.setBlockAndUpdate(base.relative(facing.getOpposite()), Blocks.STONE_PRESSURE_PLATE.defaultBlockState());

        source.sendSuccess(() -> Component.literal("Starter door built! Walk over either stone pressure plate to open it. Use /redbuild help for commands."), false);
        return 1;
    }

    private static int spawnRobot(CommandSourceStack source) throws com.mojang.brigadier.exceptions.CommandSyntaxException {
        ServerPlayer player = source.getPlayerOrException();
        ServerLevel level = source.getLevel();
        BlockPos spawn = player.blockPosition().relative(player.getDirection(), 2);

        ArmorStand robot = new ArmorStand(level, spawn.getX() + 0.5, spawn.getY(), spawn.getZ() + 0.5);
        robot.setCustomName(Component.literal("§6FireBot"));
        robot.setCustomNameVisible(true);
        robot.setShowArms(true);
        robot.setNoBasePlate(true);
        robot.addTag(ROBOT_TAG);
        robot.setInvulnerable(true);
        robot.setSilent(true);
        level.addFreshEntity(robot);

        // Make a little orange "core" using particles; purely visual, no projectile attacks.
        level.sendParticles(ParticleTypes.FLAME, robot.getX(), robot.getY() + 1.0, robot.getZ(), 8, 0.15, 0.15, 0.15, 0.01);
        source.sendSuccess(() -> Component.literal("FireBot spawned! It follows nearby players and emits decorative flame particles. Use /redbuild stopbots to remove nearby bots."), false);
        return 1;
    }

    private static int removeRobots(CommandSourceStack source) throws com.mojang.brigadier.exceptions.CommandSyntaxException {
        ServerPlayer player = source.getPlayerOrException();
        ServerLevel level = source.getLevel();
        var box = player.getBoundingBox().inflate(48.0);
        var robots = level.getEntitiesOfClass(ArmorStand.class, box, entity -> entity.getTags().contains(ROBOT_TAG));
        robots.forEach(net.minecraft.world.entity.Entity::discard);
        int count = robots.size();
        source.sendSuccess(() -> Component.literal("Removed " + count + " nearby FireBot(s)."), false);
        return count;
    }

    private static void tickRobots(MinecraftServer server) {
        for (ServerPlayer player : server.getPlayerList().getPlayers()) {
            ServerLevel level = (ServerLevel) player.level();
            var box = player.getBoundingBox().inflate(32.0);
            var robots = level.getEntitiesOfClass(ArmorStand.class, box,
                    entity -> entity.getTags().contains(ROBOT_TAG));
            for (ArmorStand robot : robots) {
                double dx = player.getX() - robot.getX();
                double dz = player.getZ() - robot.getZ();
                double distance = Math.sqrt(dx * dx + dz * dz);
                if (distance > 2.2 && distance < 24.0) {
                    double speed = 0.035;
                    robot.setPos(robot.getX() + dx / distance * speed, robot.getY(),
                            robot.getZ() + dz / distance * speed);
                }
                if (server.getTickCount() % 5 == 0) {
                    level.sendParticles(ParticleTypes.FLAME, robot.getX(), robot.getY() + 1.0,
                            robot.getZ(), 2, 0.08, 0.12, 0.08, 0.005);
                }
            }
        }
    }
}
