package com.pixelcore.fireredstone;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.ChatFormatting;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.ClickEvent;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.network.chat.Style;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.decoration.ArmorStand;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.DoorBlock;
import net.minecraft.world.level.block.LadderBlock;
import net.minecraft.world.level.block.LeverBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.AttachFace;
import net.minecraft.world.level.block.state.properties.DoubleBlockHalf;

public class FireRedstoneBuilder implements ModInitializer {
    private static final String ROBOT_TAG = "fireredstone_firebot";

    @Override
    public void onInitialize() {
        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) ->
                registerCommands(dispatcher));
        ServerTickEvents.END_SERVER_TICK.register(FireRedstoneBuilder::tickRobots);
    }

    private static void registerCommands(CommandDispatcher<CommandSourceStack> dispatcher) {
        dispatcher.register(Commands.literal("redbuild")
                .executes(ctx -> showMenu(ctx.getSource()))
                .then(Commands.literal("menu").executes(ctx -> showMenu(ctx.getSource())))
                .then(Commands.literal("help").executes(ctx -> {
                    var source = ctx.getSource();
                    source.sendSuccess(() -> Component.literal(
                            "Fire Redstone Builder: /redbuild menu | door | house | tower | bridge | farm | lamp | robot | stopbots"), false);
                    source.sendSuccess(() -> Component.literal(
                            "Tip: /redbuild menu shows tappable buttons. Builds appear in front of you and replace blocks there, so use a test world."), false);
                    return 1;
                }))
                .then(Commands.literal("door").executes(ctx -> buildDoor(ctx.getSource())))
                .then(Commands.literal("house").executes(ctx -> buildHouse(ctx.getSource())))
                .then(Commands.literal("tower").executes(ctx -> buildTower(ctx.getSource())))
                .then(Commands.literal("bridge").executes(ctx -> buildBridge(ctx.getSource())))
                .then(Commands.literal("farm").executes(ctx -> buildFarm(ctx.getSource())))
                .then(Commands.literal("lamp").executes(ctx -> buildLamp(ctx.getSource())))
                .then(Commands.literal("robot").executes(ctx -> spawnRobot(ctx.getSource())))
                .then(Commands.literal("stopbots").executes(ctx -> removeRobots(ctx.getSource()))));
    }

    // ---------- Menu ----------

    private static MutableComponent button(String label, String sub, ChatFormatting color) {
        Style style = Style.EMPTY.withColor(color).withClickEvent(new ClickEvent.RunCommand("/redbuild " + sub));
        return Component.literal("[" + label + "] ").withStyle(style);
    }

    private static int showMenu(CommandSourceStack source) {
        source.sendSuccess(() -> Component.literal("=== Fire Redstone Builder Menu (tap a button) ===")
                .withStyle(ChatFormatting.GOLD), false);
        source.sendSuccess(() -> button("House", "house", ChatFormatting.GREEN)
                .append(button("Tower", "tower", ChatFormatting.GREEN))
                .append(button("Bridge", "bridge", ChatFormatting.GREEN))
                .append(button("Farm", "farm", ChatFormatting.GREEN)), false);
        source.sendSuccess(() -> button("Door", "door", ChatFormatting.AQUA)
                .append(button("Lamp", "lamp", ChatFormatting.AQUA))
                .append(button("FireBot", "robot", ChatFormatting.YELLOW))
                .append(button("Stop Bots", "stopbots", ChatFormatting.RED)), false);
        return 1;
    }

    // ---------- Helpers ----------

    private static BlockPos at(BlockPos base, Direction facing, int right, int forward, int up) {
        return base.relative(facing.getClockWise(), right).relative(facing, forward).above(up);
    }

    private static void put(ServerLevel level, BlockPos base, Direction facing,
                            int right, int forward, int up, BlockState state) {
        level.setBlockAndUpdate(at(base, facing, right, forward, up), state);
    }

    private static void fill(ServerLevel level, BlockPos base, Direction facing,
                             int r1, int r2, int f1, int f2, int u1, int u2, BlockState state) {
        for (int r = r1; r <= r2; r++) {
            for (int f = f1; f <= f2; f++) {
                for (int u = u1; u <= u2; u++) {
                    put(level, base, facing, r, f, u, state);
                }
            }
        }
    }

    private static BlockState air() {
        return Blocks.AIR.defaultBlockState();
    }

    // ---------- Builds ----------

    private static int buildDoor(CommandSourceStack source) throws CommandSyntaxException {
        ServerPlayer player = source.getPlayerOrException();
        ServerLevel level = source.getLevel();
        BlockPos feet = player.blockPosition();
        Direction facing = player.getDirection();
        BlockPos base = feet.relative(facing, 3);
        Direction right = facing.getClockWise();

        for (int side = -1; side <= 1; side++) {
            for (int depth = -1; depth <= 1; depth++) {
                BlockPos floor = base.relative(right, side).relative(facing.getOpposite(), depth).below();
                level.setBlockAndUpdate(floor, Blocks.STONE.defaultBlockState());
            }
        }
        for (int side = -1; side <= 1; side++) {
            for (int height = 0; height <= 2; height++) {
                if (side == 0 && height <= 1) continue;
                BlockPos wall = base.relative(right, side).above(height);
                level.setBlockAndUpdate(wall, Blocks.STONE_BRICKS.defaultBlockState());
            }
        }

        BlockPos lower = base;
        BlockPos upper = base.above();
        level.setBlockAndUpdate(lower, Blocks.IRON_DOOR.defaultBlockState()
                .setValue(DoorBlock.FACING, facing)
                .setValue(DoorBlock.HALF, DoubleBlockHalf.LOWER));
        level.setBlockAndUpdate(upper, Blocks.IRON_DOOR.defaultBlockState()
                .setValue(DoorBlock.FACING, facing)
                .setValue(DoorBlock.HALF, DoubleBlockHalf.UPPER));

        level.setBlockAndUpdate(base.relative(facing), Blocks.STONE_PRESSURE_PLATE.defaultBlockState());
        level.setBlockAndUpdate(base.relative(facing.getOpposite()), Blocks.STONE_PRESSURE_PLATE.defaultBlockState());

        source.sendSuccess(() -> Component.literal("Starter door built! Use /redbuild menu for more builds."), false);
        return 1;
    }

    private static int buildHouse(CommandSourceStack source) throws CommandSyntaxException {
        ServerPlayer player = source.getPlayerOrException();
        ServerLevel level = source.getLevel();
        Direction facing = player.getDirection();
        BlockPos base = player.blockPosition().relative(facing, 3);

        // 5 wide (right -2..2), 5 deep (forward 0..4), walls 3 high, roof at height 3.
        fill(level, base, facing, -2, 2, 0, 4, 0, 4, air());
        fill(level, base, facing, -2, 2, 0, 4, -1, -1, Blocks.OAK_PLANKS.defaultBlockState());
        for (int r = -2; r <= 2; r++) {
            for (int f = 0; f <= 4; f++) {
                boolean edge = Math.abs(r) == 2 || f == 0 || f == 4;
                if (edge) {
                    fill(level, base, facing, r, r, f, f, 0, 2, Blocks.STONE_BRICKS.defaultBlockState());
                }
            }
        }
        fill(level, base, facing, -2, 2, 0, 4, 3, 3, Blocks.OAK_PLANKS.defaultBlockState());

        // Door at the front center.
        put(level, base, facing, 0, 0, 0, Blocks.OAK_DOOR.defaultBlockState()
                .setValue(DoorBlock.FACING, facing)
                .setValue(DoorBlock.HALF, DoubleBlockHalf.LOWER));
        put(level, base, facing, 0, 0, 1, Blocks.OAK_DOOR.defaultBlockState()
                .setValue(DoorBlock.FACING, facing)
                .setValue(DoorBlock.HALF, DoubleBlockHalf.UPPER));

        // Windows and torches.
        BlockState glass = Blocks.GLASS_PANE.defaultBlockState();
        put(level, base, facing, -2, 2, 1, glass);
        put(level, base, facing, 2, 2, 1, glass);
        put(level, base, facing, 0, 4, 1, glass);
        put(level, base, facing, -1, 3, 0, Blocks.TORCH.defaultBlockState());
        put(level, base, facing, 1, 3, 0, Blocks.TORCH.defaultBlockState());

        source.sendSuccess(() -> Component.literal("Small house built in front of you!"), false);
        return 1;
    }

    private static int buildTower(CommandSourceStack source) throws CommandSyntaxException {
        ServerPlayer player = source.getPlayerOrException();
        ServerLevel level = source.getLevel();
        Direction facing = player.getDirection();
        BlockPos base = player.blockPosition().relative(facing, 3);

        BlockState bricks = Blocks.STONE_BRICKS.defaultBlockState();
        fill(level, base, facing, -2, 2, 0, 4, 0, 11, air());
        fill(level, base, facing, -2, 2, 0, 4, -1, -1, bricks);
        for (int r = -2; r <= 2; r++) {
            for (int f = 0; f <= 4; f++) {
                boolean edge = Math.abs(r) == 2 || f == 0 || f == 4;
                if (edge) {
                    fill(level, base, facing, r, r, f, f, 0, 8, bricks);
                    // Battlements on top, every other block.
                    if ((r + f) % 2 == 0) {
                        put(level, base, facing, r, f, 10, bricks);
                    }
                }
            }
        }
        // Top platform with a hole for the ladder at (0, 3).
        for (int r = -2; r <= 2; r++) {
            for (int f = 0; f <= 4; f++) {
                if (r == 0 && f == 3) continue;
                put(level, base, facing, r, f, 9, Blocks.OAK_PLANKS.defaultBlockState());
            }
        }
        // Doorway at the front.
        put(level, base, facing, 0, 0, 0, air());
        put(level, base, facing, 0, 0, 1, air());
        // Ladder against the back wall, facing the player.
        BlockState ladder = Blocks.LADDER.defaultBlockState().setValue(LadderBlock.FACING, facing.getOpposite());
        for (int u = 0; u <= 10; u++) {
            put(level, base, facing, 0, 3, u, ladder);
        }
        put(level, base, facing, -1, 1, 0, Blocks.TORCH.defaultBlockState());
        put(level, base, facing, 1, 1, 0, Blocks.TORCH.defaultBlockState());

        source.sendSuccess(() -> Component.literal("Watchtower built! Enter the front doorway and climb the ladder."), false);
        return 1;
    }

    private static int buildBridge(CommandSourceStack source) throws CommandSyntaxException {
        ServerPlayer player = source.getPlayerOrException();
        ServerLevel level = source.getLevel();
        Direction facing = player.getDirection();
        BlockPos base = player.blockPosition().relative(facing, 2);

        // 15 blocks long, 5 wide, deck at ground level, fence rails on both sides.
        fill(level, base, facing, -2, 2, 0, 14, 0, 2, air());
        fill(level, base, facing, -2, 2, 0, 14, -1, -1, Blocks.OAK_PLANKS.defaultBlockState());
        fill(level, base, facing, -2, -2, 0, 14, 0, 0, Blocks.OAK_FENCE.defaultBlockState());
        fill(level, base, facing, 2, 2, 0, 14, 0, 0, Blocks.OAK_FENCE.defaultBlockState());
        for (int f = 0; f <= 14; f += 5) {
            put(level, base, facing, -2, f, 1, Blocks.TORCH.defaultBlockState());
            put(level, base, facing, 2, f, 1, Blocks.TORCH.defaultBlockState());
        }

        source.sendSuccess(() -> Component.literal("Bridge built in front of you (15 blocks long)."), false);
        return 1;
    }

    private static int buildFarm(CommandSourceStack source) throws CommandSyntaxException {
        ServerPlayer player = source.getPlayerOrException();
        ServerLevel level = source.getLevel();
        Direction facing = player.getDirection();
        BlockPos base = player.blockPosition().relative(facing, 3);

        // 9x9 wheat plot (right -4..4, forward 0..8) with water in the middle.
        fill(level, base, facing, -4, 4, 0, 8, 0, 2, air());
        fill(level, base, facing, -4, 4, 0, 8, -1, -1, Blocks.FARMLAND.defaultBlockState());
        put(level, base, facing, 0, 4, -1, Blocks.WATER.defaultBlockState());
        fill(level, base, facing, -4, 4, 0, 8, 0, 0, Blocks.WHEAT.defaultBlockState());
        put(level, base, facing, 0, 4, 0, air());

        // Fence around the plot with a gap at the front.
        for (int r = -5; r <= 5; r++) {
            for (int f = -1; f <= 9; f++) {
                boolean edge = Math.abs(r) == 5 || f == -1 || f == 9;
                if (!edge) continue;
                if (r == 0 && f == -1) continue;
                put(level, base, facing, r, f, 0, Blocks.OAK_FENCE.defaultBlockState());
            }
        }

        source.sendSuccess(() -> Component.literal("Wheat farm built! Water is in the middle. Wheat grows slowly, give it time."), false);
        return 1;
    }

    private static int buildLamp(CommandSourceStack source) throws CommandSyntaxException {
        ServerPlayer player = source.getPlayerOrException();
        ServerLevel level = source.getLevel();
        Direction facing = player.getDirection();
        BlockPos base = player.blockPosition().relative(facing, 3);

        fill(level, base, facing, -2, 2, -2, 2, 0, 2, air());
        fill(level, base, facing, -2, 2, -2, 2, -1, -1, Blocks.STONE_BRICKS.defaultBlockState());
        // Power block in the middle with a lever on top; four redstone lamps touch the power block.
        put(level, base, facing, 0, 0, 0, Blocks.STONE_BRICKS.defaultBlockState());
        put(level, base, facing, 1, 0, 0, Blocks.REDSTONE_LAMP.defaultBlockState());
        put(level, base, facing, -1, 0, 0, Blocks.REDSTONE_LAMP.defaultBlockState());
        put(level, base, facing, 0, 1, 0, Blocks.REDSTONE_LAMP.defaultBlockState());
        put(level, base, facing, 0, -1, 0, Blocks.REDSTONE_LAMP.defaultBlockState());
        put(level, base, facing, 0, 0, 1, Blocks.LEVER.defaultBlockState()
                .setValue(LeverBlock.FACE, AttachFace.FLOOR)
                .setValue(LeverBlock.FACING, facing));

        source.sendSuccess(() -> Component.literal("Lamp station built! Flip the lever on top to light the lamps."), false);
        return 1;
    }

    // ---------- FireBot ----------

    private static int spawnRobot(CommandSourceStack source) throws CommandSyntaxException {
        ServerPlayer player = source.getPlayerOrException();
        ServerLevel level = source.getLevel();
        BlockPos spawn = player.blockPosition().relative(player.getDirection(), 2);

        ArmorStand robot = new ArmorStand(level, spawn.getX() + 0.5, spawn.getY(), spawn.getZ() + 0.5);
        robot.setCustomName(Component.literal("§6FireBot"));
        robot.setCustomNameVisible(true);
        robot.setShowArms(true);
        robot.setNoBasePlate(true);
        robot.addTag(ROBOT_TAG);
        robot.setInvulnerable(true);
        robot.setSilent(true);
        level.addFreshEntity(robot);

        level.sendParticles(ParticleTypes.FLAME, robot.getX(), robot.getY() + 1.0, robot.getZ(), 8, 0.15, 0.15, 0.15, 0.01);
        source.sendSuccess(() -> Component.literal("FireBot spawned! Use /redbuild stopbots to remove nearby bots."), false);
        return 1;
    }

    private static int removeRobots(CommandSourceStack source) throws CommandSyntaxException {
        ServerPlayer player = source.getPlayerOrException();
        ServerLevel level = source.getLevel();
        var box = player.getBoundingBox().inflate(48.0);
        var robots = level.getEntitiesOfClass(ArmorStand.class, box, entity -> entity.getTags().contains(ROBOT_TAG));
        robots.forEach(net.minecraft.world.entity.Entity::discard);
        int count = robots.size();
        source.sendSuccess(() -> Component.literal("Removed " + count + " nearby FireBot(s)."), false);
        return count;
    }

    private static void tickRobots(MinecraftServer server) {
        for (ServerPlayer player : server.getPlayerList().getPlayers()) {
            ServerLevel level = (ServerLevel) player.level();
            var box = player.getBoundingBox().inflate(32.0);
            var robots = level.getEntitiesOfClass(ArmorStand.class, box,
                    entity -> entity.getTags().contains(ROBOT_TAG));
            for (ArmorStand robot : robots) {
                double dx = player.getX() - robot.getX();
                double dz = player.getZ() - robot.getZ();
                double distance = Math.sqrt(dx * dx + dz * dz);
                if (distance > 2.2 && distance < 24.0) {
                    double speed = 0.035;
                    robot.setPos(robot.getX() + dx / distance * speed, robot.getY(),
                            robot.getZ() + dz / distance * speed);
                }
                if (server.getTickCount() % 5 == 0) {
                    level.sendParticles(ParticleTypes.FLAME, robot.getX(), robot.getY() + 1.0,
                            robot.getZ(), 2, 0.08, 0.12, 0.08, 0.005);
                }
            }
        }
    }
}
